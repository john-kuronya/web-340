"use strict";

function calculateDistance(planet1, planet2) {
  return Math.abs(planet1 - planet2);
}

module.exports = calculateDistance;