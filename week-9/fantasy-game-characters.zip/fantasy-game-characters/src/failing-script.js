// failing-script.js
console.error("Simulated script failure.");
process.exit(1);
